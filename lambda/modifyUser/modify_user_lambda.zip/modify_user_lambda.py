import json
import os
import boto3

ssession = boto3.Session(region_name=os.environ['REGION'])
dynamodb_client = session.client('dynamodb')

def lambda_handler(event, context):
    try:
        print("event ->" + str(event))
        payload = json.loads(event["body"])
        print("payload ->" + str(payload))
        user_id = payload.get("id")
        first_name = payload.get("firstName")
        last_name = payload.get("lastName")

        if not user_id:
            return {
                'statusCode': 400,
                'body': json.dumps({"status": "Bad Request", "error": "Missing user ID"})
            }

        # Check if the user with the specified ID exists
        response = dynamodb_client.get_item(
            TableName=os.environ["USERS_TABLE"],
            Key={"id": {"S": user_id}}
        )

        if 'Item' not in response:
            return {
                'statusCode': 404,
                'body': json.dumps({"status": "Not Found", "error": "User ID does not exist"})
            }

        # Update the user record with new values if provided
        update_expression = "SET"
        expression_attribute_values = {}
        
        if first_name:
            update_expression += " #fn = :fn,"
            expression_attribute_values[":fn"] = {"S": first_name}
            expression_attribute_names = {"#fn": "firstName"}

        if last_name:
            update_expression += " #ln = :ln,"
            expression_attribute_values[":ln"] = {"S": last_name}
            expression_attribute_names = {"#ln": "lastName"}

        # Remove trailing comma and update the record
        update_expression = update_expression.rstrip(',')
        
        dynamodb_client.update_item(
            TableName=os.environ["USERS_TABLE"],
            Key={"id": {"S": user_id}},
            UpdateExpression=update_expression,
            ExpressionAttributeValues=expression_attribute_values,
            ExpressionAttributeNames=expression_attribute_names
        )

        return {
            'statusCode': 200,
            'body': json.dumps({"status": "User updated"})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({"status": "Server error", "error": str(e)})
        }
